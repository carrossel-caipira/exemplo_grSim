#include "vision/vision_listener.hpp"

VisionListener::VisionListener(rclcpp::Node* node, char* multicast_ip, int multicast_port, char* inteface_name) : socketFD_(-1) {
    node_ = node;
    
    MULTICAST_IP = multicast_ip;
    MULTICAST_PORT = multicast_port;
    INTERFACE_NAME = inteface_name;
}

VisionListener::~VisionListener() {
    leaveGroup();
}

int VisionListener::startSocket() {
    if (socketFD_ > 0) {
        RCLCPP_WARN(node_->get_logger(), "Tried to open socket: socket already open");
        return 0;
    }

    RCLCPP_INFO(node_->get_logger(), "Opening socket");
    socketFD_ = socket(AF_INET, SOCK_DGRAM, 0);
    if (socketFD_ < 0) {
        RCLCPP_FATAL(node_->get_logger(), "failed to create socket");
        return -1;
    }
    
    const int TRUE_FLAG = 1;
    if(setsockopt(socketFD_, SOL_SOCKET, SO_REUSEADDR, &TRUE_FLAG, sizeof(int)) < 0){
        RCLCPP_FATAL(node_->get_logger(), "failed to set socket opt");
	}

	memset(&serverAddr_, 0, sizeof(serverAddr_));
	serverAddr_.sin_family = AF_INET;
	serverAddr_.sin_port = htons(MULTICAST_PORT);
	serverAddr_.sin_addr.s_addr = htonl(INADDR_ANY);
	if(bind(socketFD_, (struct sockaddr *)&serverAddr_, sizeof(serverAddr_)) < 0){
        RCLCPP_FATAL(node_->get_logger(), "Failed to bind socket");
        close(socketFD_);

        return -1;
	}
    
    struct ip_mreqn group;
    memset(&group, 0, sizeof(group));
    group.imr_multiaddr.s_addr = inet_addr(MULTICAST_IP);
    group.imr_address.s_addr = htonl(INADDR_ANY);
	group.imr_ifindex = if_nametoindex(INTERFACE_NAME);

    if (setsockopt(socketFD_, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char *)&group, sizeof(group)) < 0) {
        RCLCPP_FATAL(node_->get_logger(), "failed setsockopt group");
        close(socketFD_);

        return -1;
    }
    return 0;
}

int VisionListener::leaveGroup() {
    if (socketFD_ < 0) {
        RCLCPP_WARN(node_->get_logger(), "Socket is not open");
        return 0;
    }

    struct ip_mreq group;
    group.imr_multiaddr.s_addr = inet_addr(MULTICAST_IP);
    group.imr_interface.s_addr = inet_addr("0.0.0.0");

    if (setsockopt(socketFD_, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char *)&group, sizeof(group)) < 0) {
        RCLCPP_FATAL(node_->get_logger(), "setsockopt(IP_DROP_MEMBERSHIP) failed");
    }

    close(socketFD_);
    socketFD_ = -1;
    return 0;
}

void VisionListener::receivePacket() {
    RCLCPP_DEBUG(node_->get_logger(), "Trying to receive packet");

    char buffer[SOCKETBUFFERSIZE_];
    
    socklen_t addrlen = sizeof(serverAddr_);
    
    int recvlen = recvfrom(socketFD_, buffer, SOCKETBUFFERSIZE_ - 1, 0, (struct sockaddr*)&serverAddr_, &addrlen);
    if (recvlen < 0) {
        RCLCPP_WARN(node_->get_logger(), "recvfrom error");
        exit(1);
    }
    
    RCLCPP_INFO(node_->get_logger(), "Received %i bytes", recvlen);
    recievedPacket_.ParseFromArray(buffer, recvlen);
}

SSL_WrapperPacket VisionListener::getPacket() {
    // newPacket_ = false;
    return this->recievedPacket_;
}

// TODO: Add new packet verification
// bool VisionListener::hasNewPacket() const {
//     return newPacket_;
// } 